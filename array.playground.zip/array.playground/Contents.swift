import UIKit
import CoreFoundation

//var greeting = "Hello, playground"
let myarray:[(Int,String)]=[(1,"a"),(2,"z"),(3,"c"),(12,"o"),(19,"d")]

let myarray2 = myarray.map{(number:Int,string:String)in
    return(number*number,string)}
print(myarray2)

var myarray3 = myarray2.filter{(number:Int,string:String)->Bool in return(number%2==0)}
 print(myarray3)

var myarray4 = myarray3.sorted{$0.1<$1.1}

print(myarray4)
